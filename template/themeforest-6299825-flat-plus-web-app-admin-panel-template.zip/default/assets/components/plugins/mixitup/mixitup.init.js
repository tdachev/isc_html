(function($)
{
	
	$('.mixitup').mixitup({ showOnLoad: 'mixit-filter-1' });

})(jQuery);